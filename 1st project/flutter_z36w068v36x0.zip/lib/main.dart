import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      title: 'Flutter App!!',
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      home: Homepage()
    );
}
  
} bool secure=true;
class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 17, 24, 75),

centerTitle:true,
        title: Text("LOGIN PAGE",style: TextStyle(fontSize: 28, color: Colors.white)
        ),
        leading:Icon(Icons.message,color:Colors.white,size:29),
        actions:[
          Icon(Icons.search,color:Colors.white,size:29),
          SizedBox(width:18,),
          Icon(Icons.menu,color:Colors.white,size:29),
         
    ]
   
      ),  
   
body: SingleChildScrollView(
  child:   Column(
  
      children:[
             SizedBox(height: 40),    Center(
        child: Image.asset('assets/user-1.410x512.png'
      ,width:250,
     height:250,
           ),
                 ),
                
                 Padding(
                  padding:EdgeInsets.all(30),
                 ),
            Column(children:[
            TextFormField(
              decoration: InputDecoration(
                label: Text('enter Email Or Phone Number'),
                prefixIcon: Icon(Icons.person,color:Colors.black54),
              
                border: OutlineInputBorder(
                  borderSide: BorderSide(),
                ),
              ),
  
  ),
  SizedBox(height: 40),
  TextFormField(
    obscureText:secure,
              decoration: InputDecoration(
                label: Text('enter Password'),
                prefixIcon: Icon(Icons.lock,color:Colors.black54),
  suffixIcon: IconButton( onPressed: (){
    setState((){
  secure= !secure;
    });
  },
         icon: Icon (Icons.remove_red_eye),
         
        ),
                border: OutlineInputBorder(
                  borderSide: BorderSide(),
            ),
            )
            ),
            SizedBox(height: 40),
  InkWell(
  onTap:(){
    print('logged');
  },
    child:Container(
      width:300
      ,
      height:100,
      padding:EdgeInsets.all(20),
      color: Color.fromARGB(255, 17, 24, 75),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children:
        [Text('Login',style:TextStyle(color:Colors.white, fontSize:25)),
        SizedBox(width: 5),
         Icon(Icons.login,color:Colors.white,size:25),
        ],
      ),
     ) ,
  ),
    
     ]
    
  
    )
  ]
  ),
)
);}}